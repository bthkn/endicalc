// var cardboardCost // стоимость картона
// var printCost = this.db['printCosts']["4+0"]['100']
// var springCost = 0 // стоимость пружины
// var grommetCost = 0 // стоимость люверса
// var blockStd = 0 // календарный блок стандарт
// var block85 = 0 // календарный блок 85*115
// var skoba = 2.2 // стоимость скобы
// var begunok = 0 // стоимость бегунка
// var edition = 100 // тираж
// var kRent = 1.77 // коэффициент рентабельности

// var total6 = ((cardboardTabNum * cardboardCost) + printCost + (springCost * springTabNum)  + (grommetCost * grommetTabNum) + blockStd + block85 + skoba + begunok) * edition * kRent
// console.log('Календари = ' + total6)

var app = new Vue({
  el: '#calendarsCalc',
  data: {
    currentProduct: 'Календари',
    isLaminated: undefined,
    isCorners: undefined,
    edition: undefined,
    db: {
      "paperTypes": [ 
        "Офсетная 80 гр",
        "Maxigloss 130гр",
        "Maxigloss 170гр./м.кв",
        "Delight gloss в упак C2S Art Board мел.картон 2 ст. 310",
        "Arconvert",
        "Тач кавер 300",
        "ICELASER Лен",
        "Comet брилиант 300 гр",
        "Acquerello 300 гр",
        "Nettuno 300 гр",
        "Sirio pearl 300 гр",
        "Splendorgel 300 гр",
        "TintoRetto 300 гр"
      ],
      "paperCosts": {
        "Офсетная 80 гр": 1.84,
        "Maxigloss 130гр": 2.21,
        "Maxigloss 170гр./м.кв": 2.89,
        "Delight gloss в упак C2S Art Board мел.картон 2 ст. 310": 6.85,
        "Arconvert": 9.5,
        "Тач кавер 300": 86.62,
        "ICELASER Лен": 27.41,
        "Comet брилиант 300 гр": 44.73,
        "Acquerello 300 гр": 33.3,
        "Nettuno 300 гр": 34.5,
        "Sirio pearl 300 гр": 48.6,
        "Splendorgel 300 гр": 25.5,
        "TintoRetto 300 гр": 27.7
      },
      "printCosts": {
        "4+0": {
          "20": 1.6,
          "100": 8
        },
        "4+4": {
          "20": 3.2,
          "100": 16
        },
        "1+0": {
          "20": 1.6,
          "100": 8
        },
        "1+1": {
          "20": 3.2,
          "100": 16
        },
        "4+1": {
          "20": 3.2,
          "100": 16
        }
      },
      "additional": {
        "corners" : {
          "50": 175,
          "100": 252,
          "200": 315,
          "300": 378,
          "400": 441,
          "500": 504,
          "1000": 819,
          "2000": 913.5
        },
        "laminat" : {
          "50": 2205,
          "100": 4400,
          "200": 8800,
          "300": 13200,
          "400": 17600,
          "500": 22000,
          "1000": 0,
          "2000": 0
        },
        "biegen" : {
          "50": 141.75,
          "100": 220.5,
          "200": 378,
          "300": 535.5,
          "400": 693,
          "500": 850.5,
          "1000": 1638,
          "2000": 0
        }
      },
      "kRentOf": {
        "calendars": {
          "basic": {
            "4+0": {
              "5": 7,
              "50": 4,
              "100": 3.7,
              "200": 3.15,
              "300": 2.71,
              "500": 2.34,
              "700": 2.2,
              "1000": 2,
              "2000": 1.9,
              "3000": 1.8
            }
          },
          "diy": {
            "4+0": {
              "5": 7,
              "50": 4,
              "100": 4,
              "200": 3.5,
              "300": 3,
              "500": 2.85,
              "700": 2.7,
              "1000": 2.65,
              "2000": 2.6,
              "3000": 2.5
            }
          },
          "vertical": {
            "4+0": {
              "5": 7,
              "50": 5.8,
              "100": 4.15,
              "200": 4,
              "300": 3.6,
              "500": 3.25,
              "700": 3.2,
              "1000": 3.2,
              "2000": 3.2,
              "3000": 3.2
            }
          },
          "horizontal": {
            "4+0": {
              "5": 7,
              "50": 6,
              "100": 5.9,
              "200": 5.8,
              "300": 5.2,
              "500": 4,
              "700": 3.9,
              "1000": 3.9,
              "2000": 3.9,
              "3000": 3.9 
            }
          }
        }
      },
      "calendars": {
        "Домик самосборный": {
          "картон": 0.5,
          "печать": 0.5,
          "пружина": 0,
          "люверс": 0,
          "блок_стандарт": 0,
          "блок_85x115": 0,
          "скоба": 2,
          "бегунок": 0
        },
        "Домик с блоками вертикальный": {
          "картон": 0.35,
          "печать": 0.35,
          "пружина": 0.3,
          "люверс": 0,
          "блок_стандарт": 0,
          "блок_85x115": 1,
          "скоба": 0,
          "бегунок": 0
        },
        "Домик с блоками горизонтальный": {
          "картон": 0.5,
          "печать": 0.5,
          "пружина": 0.3,
          "люверс": 0,
          "блок_стандарт": 0,
          "блок_85x115": 1,
          "скоба": 0,
          "бегунок": 0
        },
        "Моно стандарт": {
          "картон": 2,
          "печать": 2,
          "пружина": 1,
          "люверс": 1,
          "блок_стандарт": 0.3,
          "блок_85x115": 0,
          "скоба": 0,
          "бегунок": 1
        },
        "ТРИО economy": {
          "картон": 2,
          "печать": 1,
          "пружина": 3,
          "люверс": 1,
          "блок_стандарт": 1,
          "блок_85x115": 0,
          "скоба": 0,
          "бегунок": 1
        },
        "Трио big size": {
          "картон": 4,
          "печать": 2,
          "пружина": 4.5,
          "люверс": 1,
          "блок_стандарт": 1,
          "блок_85x115": 0,
          "скоба": 0,
          "бегунок": 1
        },
        "Трио standart": {
          "картон": 2,
          "печать": 1.25,
          "пружина": 3,
          "люверс": 1,
          "блок_стандарт": 1,
          "блок_85x115": 0,
          "скоба": 0,
          "бегунок": 1
        }
      }
    }
    
  },
  methods: {
      getTotal() {
        if (this.currentProduct == 'Календари') {
          // calendars
          var cardboardType = document.getElementById('cardboardType').value
          var paper = document.getElementById('visitCards-paper').value
          var color = document.getElementById('visitCards-color').value

          // var paperCost = this.db['paperCosts'][paper]
          var printCost = this.db['printCosts']["4+0"]['100'] //
          // var kRent = this.db['kRentOf']['visitCards'][cardboardType][""+color][this.edition]
          // var lamCost = this.isLaminated ? this.db['additional']['laminat'][this.edition] : 0
          // var cornerCost = this.isCorners ? this.db['additional']['corners'][this.edition] : 0

          var total = ((paperCost + printCost) / 24) * this.edition * kRent + lamCost + cornerCost
          
          alert('товар: Календари\nкол-во: '+this.edition+'\nстоимость: '+total+' ('+total/this.edition+' \u20BD/шт)')
        }
      }
  }
})